# flutter_application_1

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

this code is genrated by chatgpt and modified by sukhmanpreet Singh

/i also discuss some problems with my friend dipanshu

/ this app is mainly for andriod users

/ In main.dart file i usually add colors for the coloums and borders i also add images from the web 


