

import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(DigitalPictureFrameApp());
}

class DigitalPictureFrameApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DigitalPictureFrame(),
    );
  }
}

class DigitalPictureFrame extends StatefulWidget {
  @override
  _DigitalPictureFrameState createState() => _DigitalPictureFrameState();
}

class _DigitalPictureFrameState extends State<DigitalPictureFrame> {
  final List<String> imageUrls = [
    "https://th.bing.com/th/id/OIP.pAZoFc15YsTWVI5xkOFnKwHaEo?w=245&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7",
    "https://th.bing.com/th/id/OIP.vlFp_jWM3fklHxAHuX1MyAHaEo?w=245&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7",
    "https://th.bing.com/th/id/OIP.IXj0Qe_OvvEnRlk7s7ESXAHaEZ?w=262&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7",
    "https://th.bing.com/th/id/OIP.XEFj9uJHOuQ_hZibfjXcSwHaEK?w=263&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7",
  ];

  int currentIndex = 0;
  bool isPaused = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  void startTimer() {
    timer = Timer.periodic(Duration(seconds: 10), (timer) {
      if (!isPaused) {
        setState(() {
          currentIndex = (currentIndex + 1) % imageUrls.length;
        });
      }
    });
  }

  void togglePause() {
    setState(() {
      isPaused = !isPaused;
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: newMethod,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.brown, width: 10),
                color: Colors.white,
              ),
              padding: EdgeInsets.all(10),
              child: Image.network(
                imageUrls[currentIndex],
                width: 500,
                height: 500,
                fit: BoxFit.contain,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: togglePause,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 79, 72, 121),
              ),
              child: Text(
                isPaused ? "Resume" : "Pause",
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  dynamic get newMethod {
    var bisque = colors;
    return bisque;
  }
  
  get colors => null;

 
} 
